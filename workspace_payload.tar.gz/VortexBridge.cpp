export module Vortex3D.Bridge;

import Vortex3D.Mesh;
import Vortex3D.Diagnostics;

export namespace Vortex3D {
    class NativeEngineBridge {
    public:
        NativeEngineBridge() = default;
        void initializationSequence();
        void dispatchRenderFrame();
        void terminateEngine();
    };
}
