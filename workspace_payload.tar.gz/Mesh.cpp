module;
// Global module fragment area: safe for traditional preprocessor includes
#include <vector>
#include <cstdint>

export module Vortex3D.Mesh;

export namespace Vortex3D {
    struct Vertex {
        float x, y, z;
        float nx, ny, nz;
        float u, v;
    };

    class Mesh {
    public:
        Mesh() = default;
        void allocateBuffers(const std::vector<Vertex>& vertices, const std::vector<uint32_t>& indices);
        void bind() const;
        size_t getIndexCount() const { return indexCount; }

    private:
        uint32_t vao = 0;
        uint32_t vbo = 0;
        uint32_t ebo = 0;
        size_t indexCount = 0;
    };
}
