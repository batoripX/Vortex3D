module;
#include <iostream>

export module Vortex3D.Main;

import Vortex3D.Mesh;
import Vortex3D.Diagnostics;
import Vortex3D.Bridge;

// Code implementation compiled safely alongside imports
void executeEngineRuntime() {
    std::cout << "Booting Vortex3D Graphics Architecture Engine Layer..." << std::endl;
    Vortex3D::DiagnosticManager::getInstance().logEvent(
        Vortex3D::ErrorLevel::Info, "CoreRuntime", "Engine core subsystem pre-initialization complete."
    );
}
