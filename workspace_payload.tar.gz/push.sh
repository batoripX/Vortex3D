#!/usr/bin/env bash
set -e

OWNER="batoripX"
REPO="Vortex3D"
BRANCH="main"

echo "Syncing latest build configurations..."
YML_BASE64=$(base64 -w 0 ".github/workflows/ci.yml")
YML_SHA=$(gh api "repos/$OWNER/$REPO/contents/.github/workflows/ci.yml?ref=$BRANCH" --jq '.sha' 2>/dev/null || echo "")

if [ -z "$YML_SHA" ]; then
  gh api --method PUT "repos/$OWNER/$REPO/contents/.github/workflows/ci.yml" \
    --field message="Force sync pipeline" \
    --field content="$YML_BASE64" \
    --field branch="$BRANCH" > /dev/null
else
  gh api --method PUT "repos/$OWNER/$REPO/contents/.github/workflows/ci.yml" \
    --field message="Force update pipeline" \
    --field content="$YML_BASE64" \
    --field sha="$YML_SHA" \
    --field branch="$BRANCH" > /dev/null
fi

echo "Compressing workspace with system exclusions..."
tar --exclude='workspace_payload.tar.gz' \
    --exclude='.git' \
    --exclude='.module_cache' \
    --exclude='.axs' \
    --exclude='.cache' \
    --exclude='.config' \
    --exclude='.local' \
    --exclude='opt' \
    --exclude='.bash_history' \
    --exclude='.gitconfig' \
    -czf workspace_payload.tar.gz .

echo "Uploading engine data structure..."
CONTENT_BASE64=$(base64 -w 0 "workspace_payload.tar.gz")
SHA=$(gh api "repos/$OWNER/$REPO/contents/workspace_payload.tar.gz?ref=$BRANCH" --jq '.sha' 2>/dev/null || echo "")

if [ -z "$SHA" ]; then
  gh api --method PUT "repos/$OWNER/$REPO/contents/workspace_payload.tar.gz" \
    --field message="Deploy clean engine asset cluster" \
    --field content="$CONTENT_BASE64" \
    --field branch="$BRANCH" > /dev/null
else
  gh api --method PUT "repos/$OWNER/$REPO/contents/workspace_payload.tar.gz" \
    --field message="Update clean engine asset cluster" \
    --field content="$CONTENT_BASE64" \
    --field sha="$SHA" \
    --field branch="$BRANCH" > /dev/null
fi

rm workspace_payload.tar.gz

echo "------------------------------------------------------"
echo "Tracking live APK compilation on GitHub Runner..."
echo "------------------------------------------------------"
sleep 2

gh run watch --repo "$OWNER/$REPO"
