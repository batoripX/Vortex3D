#!/usr/bin/env bash
set -e

OWNER="batoripX"
REPO="Vortex3D"
BRANCH="main"

echo "Compressing entire workspace with strict system filters..."

# Archive the current directory while filtering out every hidden cache and system asset
tar --exclude='workspace_payload.tar.gz' \
    --exclude='.git' \
    --exclude='.module_cache' \
    --exclude='.axs' \
    --exclude='.cache' \
    --exclude='.config' \
    --exclude='.local' \
    --exclude='opt' \
    --exclude='.bash_history' \
    --exclude='.gitconfig' \
    -czf workspace_payload.tar.gz .

echo "Uploading unified code layer to GitHub repository..."
CONTENT_BASE64=$(base64 -w 0 "workspace_payload.tar.gz")

SHA=$(gh api "repos/$OWNER/$REPO/contents/workspace_payload.tar.gz?ref=$BRANCH" --jq '.sha' 2>/dev/null || echo "")

if [ -z "$SHA" ]; then
  gh api --method PUT "repos/$OWNER/$REPO/contents/workspace_payload.tar.gz" \
    --field message="Deploy clean engine asset layer" \
    --field content="$CONTENT_BASE64" \
    --field branch="$BRANCH" > /dev/null
else
  gh api --method PUT "repos/$OWNER/$REPO/contents/workspace_payload.tar.gz" \
    --field message="Update clean engine asset layer" \
    --field content="$CONTENT_BASE64" \
    --field sha="$SHA" \
    --field branch="$BRANCH" > /dev/null
fi

rm workspace_payload.tar.gz

echo "------------------------------------------------------"
echo "Tracking live APK compilation on GitHub Runner..."
echo "------------------------------------------------------"
sleep 2

gh run watch --repo "$OWNER/$REPO"
