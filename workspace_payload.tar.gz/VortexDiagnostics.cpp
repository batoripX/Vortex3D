module;
#include <string>
#include <vector>
#include <cstdint>

export module Vortex3D.Diagnostics;

export namespace Vortex3D {
    enum class ErrorLevel : uint32_t {
        Info = 0,
        Warning = 1,
        Critical = 2
    };

    struct DiagnosticPayload {
        ErrorLevel level;
        std::string subsystem;
        std::string loggingMessage;
        uint64_t timestampMicros;
    };

    class DiagnosticManager {
    public:
        static DiagnosticManager& getInstance() {
            static DiagnosticManager instance;
            return instance;
        }

        void logEvent(ErrorLevel level, const std::string& subsystem, const std::string& message);
        std::vector<DiagnosticPayload> fetchLogs() const;
        void clearLogs();

    private:
        DiagnosticManager() = default;
        std::vector<DiagnosticPayload> systemLogs;
    };
}
